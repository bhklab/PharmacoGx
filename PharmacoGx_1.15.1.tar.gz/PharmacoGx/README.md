[![Build Status](https://travis-ci.org/bhklab/PharmacoGx.svg?branch=master)](https://travis-ci.org/bhklab/PharmacoGx)
[![codecov](https://codecov.io/gh/bhklab/PharmacoGx/branch/master/graph/badge.svg)](https://codecov.io/gh/bhklab/PharmacoGx)
[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/bhklab/PharmacoGx?branch=master&svg=true)](https://ci.appveyor.com/project/bhklab/PharmacoGx)

PharmacoGx
==========

R package to analyze large-scale pharmacogenomic datasets.


Dependencies:

All dependencies are available from CRAN or Bioconductor.
